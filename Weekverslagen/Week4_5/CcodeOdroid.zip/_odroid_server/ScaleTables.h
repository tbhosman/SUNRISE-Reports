/*
 * ScaleTables.h
 *
 *  Created on: May 9, 2016
 *      Author: tim
 */

#ifndef SCALETABLES_H_
#define SCALETABLES_H_

extern double victronScale[181];
extern double weatherScale[112];
extern int victronType[181];

#endif /* SCALETABLES_H_ */
