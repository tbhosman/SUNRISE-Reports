/*
 ============================================================================
 Name        : BicycleShed.c
 Author      : Palinecko
 Version     :
 Copyright   : Free stuff --- I guess--no warranty for sure
 Description : The is the main program for the eBike Charging station.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
#include <modbus.h>
#include <stdint.h>
#include <curl/curl.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>
#include <sys/syscall.h>

#include "readDatabase.h"
#include "Victron.h"
#include "Weather.h"
#include "Display.h"
#include "ServerCom.h"
#include "GPIOs.h"


void *function15s();
void *function10m();
void *functionData();
void *functionVictronData();

int main(void) {

	/*LEDBlink();
	puts("done");*/

	int j=1; // for the infinite loop to make the application run like a donkey in circus
	int n;// measuring time in seconds

	pthread_t thread1;
	pthread_t thread2;
	pthread_t thread3; //thread for Solar temperature, similar as thread2
	pthread_t thread4; // thread for Victron data, similar as thread2
	int iret1,iret2,iret3,iret4;

	while (1){
        printf("\nj is %d \n",j);

		clock_t start = clock(),diff;

		/*NEW THREAD IS CREATED every 5 minutes to write weather values to the server */
		if(j==10 || j==30){
			/*write weather data*/
			iret2 = pthread_create(&thread2,NULL,function10m,NULL);
			if(iret2)
			{
				fprintf(stderr,"Error-pthread_create() return code: %d \n",iret2);
				exit(EXIT_FAILURE);
			}
			pthread_join(thread2,NULL);
		} else { //If data is not sent to server, only read weather for display
            /*Creating independent threads--each is executing one function(this is a bit tricky, if the data are going to be displayed they have to be read)*/
            iret1 = pthread_create(&thread1,NULL,function15s,NULL);
            if(iret1)
            {
                fprintf(stderr,"Error-pthread_create() return code: %d \n",iret1);
                exit(EXIT_FAILURE);
            }

            printf("pthread_create() was successful, %d \n",iret1);

            pthread_join(thread1,NULL);
		}

		/*NEW THREAD IS CREATED every 10 minutes to write temperature values to the server */
		if(j==20){
			/*write Solar data*/
			iret3 = pthread_create(&thread3,NULL,functionData,NULL);
			if(iret3)
			{
				fprintf(stderr,"Error-pthread_create() return code: %d \n",iret2);
				exit(EXIT_FAILURE);
			}
			pthread_join(thread3,NULL);
		}

		/*NEW THREAD IS CREATED every 10 minutes to write Victron values to the server */
		if(j==40){
			/*write Victron data*/
			iret4 = pthread_create(&thread4,NULL,functionVictronData,NULL);
			if(iret4)
			{
				fprintf(stderr,"Error-pthread_create() return code: %d \n",iret2);
				exit(EXIT_FAILURE);
			}
			pthread_join(thread4,NULL);
			j=0;
		}

		diff = clock()-start;

		printf("the time taken was %f \n",((float)diff/CLOCKS_PER_SEC));
		n = 15 - diff/CLOCKS_PER_SEC;
		sleep(n); /*pause before next iteration*/

		j++;
	}

	return EXIT_SUCCESS;
}
/*THREAD FUNCTION TO READ CHARGER STATUS FROM THE SERVER. ALSO DISPLAYS THE CURRENT STATUS OF THE CHARGERS ON THE LOCAL DISPLAY*/
void *function15s()
{
	htmlDisplay();
	printf("Charger function running \n");
	pthread_exit(NULL);
}
/*THREAD FUNCTION TO READ&SEND WEATHER DATA also displays the data on the local display*/
void *function10m()
{
	WeatherDisplay();
	printf("Weather function running \n");
	pthread_exit(NULL);
}
/*THREAD FUNCTION TO READ&SEND SOLAR PANEL TEMPERATURE*/
void *functionData(){
	/*READ SOLAR TEMP. STATION DATA*/
	double *solar;
	//solar = (uint16_t*)malloc(6*sizeof(uint16_t));
	solar = readTemperatureSensors(); // reading data from registers
	printf("Temperature function running \n");

	int i = 0;
	for(i = 0; i < 6; i++){
        printf("Temp-Sensor %d: %f degrees\n", i+1, solar[i]);
	}
	/*SEND THE SOLAR TEMP. DATA TO SERVER*/
	writeSolarToServer(solar); //send data to server
	free(solar);
	pthread_exit(NULL);
}

/*THREAD FUNCTION FOR VICTRON DATA---uploads data to all 4 Victron Databases*/

void *functionVictronData()
{
    double *victron;

//	/*READ DATA FROM VICTRON AND SEND THEM TO THE SERVER*/
	victron = readVictron(3,38);
	writeVictron1ToServer(victron); //Victron VEBUS data
	free(victron);

	/*repeat for second chunk of data*/
	victron = readVictron(259,303);
	writeVictron2ToServer(victron); //Battery data
	free(victron);

//    /*repeat for third chunk of data*/
	victron = readVictron(774,785);
	writeVictron3ToServer(victron); //Solarcharger data
	free(victron);

//  /*repeat for fourth chunk of data*/
	//victron = ReadVictron(2600,2608);
	//writeVictron4ToServer(victron); //Grid data
	//free(victron);

	/*exit thread --- mutex is the reason*/
	//sleep(1);
	puts("Victron function running");
	pthread_exit(NULL);
}
