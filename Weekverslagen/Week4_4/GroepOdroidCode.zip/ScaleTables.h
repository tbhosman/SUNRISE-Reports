/*
 * ScaleTables.h
 *
 *  Created on: May 9, 2016
 *      Author: tim
 */

#ifndef SCALETABLES_H_
#define SCALETABLES_H_

extern double VictronScale[181];
extern double WeatherScale[112];
extern int VictronType[181];

#endif /* SCALETABLES_H_ */
