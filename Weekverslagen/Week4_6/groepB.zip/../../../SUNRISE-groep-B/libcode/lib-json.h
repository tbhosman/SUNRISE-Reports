#ifndef LIB_JSON_H
#define LIB_JSON_H
#include <stdint.h>

char* add_headers(const char*, const char*, const char*);
int connect_tudelft(const char*,const char*,int,char*);
char *readchunk(int);
void cleanup(int);
char* find_message(int);
int get_content_length(void);
int json_decode_arr(char*,uint16_t**);
char* json_encode_arr(double*, int);
void cleanJsonArr(void);
char* read_ans(int);
void libJson(void);
void addStringToBuffer(char*);
void emptyBuffer(void);
int bufferHasContent(void);
#endif // LIB_JSON_H
